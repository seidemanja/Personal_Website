export const MAX_RESUME_PAGE_WIDTH = 1840;

export const RESUME_PDF_URL =
  '/pdfs/Joshua_Seideman_Resume_05232026.pdf';
