import { pdfjs } from 'react-pdf';
import { RESUME_PDF_URL } from './resumeConstants.js';

let resumeDocumentPromise;
let resolvedResumeDocument = null;

export function getLoadedResumePdf() {
  return resolvedResumeDocument;
}

export function preloadResumePdf() {
  if (!resumeDocumentPromise) {
    pdfjs.GlobalWorkerOptions.workerSrc = new URL(
      'pdfjs-dist/build/pdf.worker.min.mjs',
      import.meta.url,
    ).toString();
    const loadingTask = pdfjs.getDocument(RESUME_PDF_URL);

    resumeDocumentPromise = loadingTask.promise
      .then((pdfDocument) => {
        resolvedResumeDocument = pdfDocument;
        return pdfDocument;
      })
      .catch((error) => {
        resumeDocumentPromise = undefined;
        resolvedResumeDocument = null;
        throw error;
      });
  }

  return resumeDocumentPromise;
}
